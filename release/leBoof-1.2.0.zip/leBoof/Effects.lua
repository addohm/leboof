-- leBoof: animations and sounds.
--
-- Glows are handed to Blizzard's aura buttons (Display.lua, Glow.lua), which show them in combat
-- too: a warning glow in the game's refresh window (the end of the buff), and an expired glow on
-- the keep row's red copy (it only shows while the buff is missing). Nothing else moves.
--
-- Sounds need to know when something happened, and in combat addons can't read buffs. So:
--   running out     one sound when a buff's time left goes under its warning time (the player
--                   picks it; "auto" is each buff's own). Out of combat from the buff's real timer;
--                   in combat timed from the player's own cast (UNIT_SPELLCAST_SUCCEEDED is
--                   readable) with the duration last seen out of combat. Never twice for one cast.
--   out of combat   sounds when a buff appears or drops, and a warning on entering combat with a
--                   "keep up" buff missing (from the last out-of-combat look)
--   Blizzard's Cooldown Manager can play sounds in combat when a buff is applied or removed:
--   leBoof only points there.
--
-- Settings: ns.db.effects holds the defaults, ns.db.fx[key] a buff's own choices (nil = default).
local _, ns = ...

local Fx = {}
ns.Fx = Fx

Fx.SOUNDS = {
	{ "none", "None" },
	{ "RAID_WARNING", "Raid warning" },
	{ "READY_CHECK", "Ready check" },
	{ "RAID_BOSS_EMOTE_WARNING", "Boss emote" },
	{ "UI_RAID_BOSS_WHISPER_WARNING", "Boss whisper" },
	{ "ALARM_CLOCK_WARNING_3", "Alarm clock" },
	{ "TELL_MESSAGE", "Whisper" },
	{ "MAP_PING", "Map ping" },
}
Fx.WARNS = {
	{ "auto", "Each buff's own" }, { 3, "3 s" }, { 5, "5 s" }, { 10, "10 s" }, { 15, "15 s" },
	{ 30, "30 s" }, { 60, "1 min" }, { 120, "2 min" }, { 300, "5 min" }, { 600, "10 min" },
}

Fx.ALPHAS = {
	{ 1, "100%" }, { 0.9, "90%" }, { 0.75, "75%" }, { 0.6, "60%" }, { 0.5, "50%" }, { 0.4, "40%" }, { 0.25, "25%" },
}
Fx.YESNO = { { false, "No" }, { true, "Yes" } }

function Fx.Seconds(s)
	if s >= 60 and s % 60 == 0 then return (s / 60) .. " min" end
	return s .. " s"
end

local function Label(list, value)
	for _, v in ipairs(list) do
		if v[1] == value then return v[2] end
	end
	return tostring(value)
end
Fx.Label = Label

-- why: what the sound is for, for the sound log (/leboof soundlog).
function Fx.Play(name, why)
	local id = name and name ~= "none" and SOUNDKIT and SOUNDKIT[name]
	if id then
		if ns.SoundLog then ns.SoundLog.Reason(why) end
		PlaySound(id, "Master")
	end
end

-- A buff's setting: its own choice, else the default for its row.
--   expiring, expiringColor             the warning glow near the end (Glow.STYLES, Glow.COLORS)
--   missing, missingColor               the expired glow on the red copy
--   upAlpha, upGrey                     the icon's opacity (0..1) and greyed or not, while it's up
--   warn                                the warning time: seconds, or "auto" (the buff's own)
--   sExpiring                           the running-out sound (in combat too, for your own casts)
--   sGained, sLost, sCombat             out-of-combat sounds (sCombat: entering combat without it)
function Fx.Default(e, field)
	local d = ns.db.effects
	local mode = ns.Mode(e)
	local keep = mode == "keep" or mode == "missing" -- the top row's buffs
	if field == "expiring" or field == "expiringColor" or field == "missing" or field == "missingColor"
		or field == "upAlpha" or field == "upGrey" then
		return d[field]
	end
	if field == "sGained" then return keep and "none" or d.upGained end
	if field == "sLost" then return keep and d.keepLost or d.upLost end
	if field == "sExpiring" then return keep and d.keepExpiring or "none" end
	if field == "sCombat" then return keep and d.combatMissing or "none" end
	if field == "warn" then return d.warn end
end

-- A buff's warning time in seconds: when its time left turns red and "running out" plays.
function Fx.Warn(e)
	local w = Fx.Get(e, "warn")
	if type(w) ~= "number" then return e.warn or 0 end
	return w
end

-- Before glow styles, the two glows were just on or off.
local OLD_GLOW = { on = "pulse", off = "none" }

function Fx.Get(e, field)
	local own = ns.db.fx[e.key]
	local value
	if own and own[field] ~= nil then value = own[field] else value = Fx.Default(e, field) end
	if field == "expiring" or field == "missing" then value = OLD_GLOW[value] or value end
	return value
end

-- value nil goes back to the default.
function Fx.Set(e, field, value)
	local fx = ns.db.fx
	fx[e.key] = fx[e.key] or {}
	fx[e.key][field] = value
	if next(fx[e.key]) == nil then fx[e.key] = nil end
	ns.Refresh()
end

-- Out of combat: what's up, and when it ends ---------------------------------------------------

local Secret = function(v) return (issecretvalue and issecretvalue(v)) or false end

-- key -> expiration time (0 for no time limit) for every tracked buff that's up; nil if unknown.
local state
-- Whether a buff changed since state was read, while the game hid them (it can outside combat too).
local stale = false
local played = {} -- key -> the expiration a "running out" sound was played for

-- Learned durations, per character (talents change them): spellID -> seconds.
local function Durations()
	local all = leBoofDB.durations or {}
	leBoofDB.durations = all
	local me = ns.Profiles.CharKey()
	all[me] = all[me] or {}
	return all[me]
end

local learned = false -- a duration was learned or changed in the last read

-- A buff's full duration, as last seen out of combat (the longest of its spell IDs); nil if never.
function Fx.Duration(e)
	local durations, best = Durations(), nil
	for _, id in ipairs(e.idList or {}) do
		local d = durations[id]
		if d and (not best or d > best) then best = d end
	end
	return best
end

local function ReadState()
	learned = false
	local buffs = ns.ReadBuffs()
	if not buffs then return nil end
	local now = GetTime()
	local found = {}
	local durations = Durations()
	for _, b in ipairs(buffs) do
		local e = ns.EntryForSpell(b.spellId)
		if e and ns.Mode(e) ~= "off" then
			local exp = (b.expirationTime and b.expirationTime > 0) and b.expirationTime or 0
			found[e.key] = math.max(found[e.key] or 0, exp)
		end
		if b.duration and b.duration > 0 and durations[b.spellId] ~= b.duration then
			durations[b.spellId] = b.duration
			learned = true
		end
	end
	-- Weapon enchants.
	local ok, hasMain, mainMs, _, _, hasOff, offMs = pcall(GetWeaponEnchantInfo)
	if ok and not Secret(hasMain) and not Secret(hasOff) then
		if hasMain and mainMs and ns.Mode(ns.byKey.mainhand) ~= "off" then found.mainhand = now + mainMs / 1000 end
		if hasOff and offMs and ns.Mode(ns.byKey.offhand) ~= "off" then found.offhand = now + offMs / 1000 end
	end
	return found
end

local function Compare(old, new)
	for _, e in ipairs(ns.Entries()) do
		local was, is = old[e.key], new[e.key]
		if is and not was then
			Fx.Play(Fx.Get(e, "sGained"), "appeared: " .. e.label)
		elseif was and not is then
			Fx.Play(Fx.Get(e, "sLost"), "dropped: " .. e.label)
		end
	end
end

-- Re-reads the buffs while the game shows them; quiet = take them as the new starting point,
-- without sounds.
function Fx.Update(quiet)
	local new = not ns.AurasHidden() and ReadState()
	if not new then
		stale = true -- leBoof couldn't look, so a change may have gone unseen
		return
	end
	if state and not quiet then Compare(state, new) end
	state, stale = new, false
	-- A new or changed duration retimes the keep row's warning glows: rebuild after this read.
	if learned then
		learned = false
		C_Timer.After(0, function() ns.Refresh(true) end)
	end
end

local castPlayed = {} -- key -> when the cast it was played for in combat should end

-- Every second while buffs can be read: "running out" sounds, from the expirations last read.
local function CheckExpiring()
	if ns.AurasHidden() or not state then return end
	local now = GetTime()
	for _, e in ipairs(ns.Entries()) do
		local exp = state[e.key]
		if exp and exp > 0 and played[e.key] ~= exp then
			local left = exp - now
			if castPlayed[e.key] and math.abs(castPlayed[e.key] - exp) < 3 then
				played[e.key] = exp -- already played for this cast, in combat
			elseif left > 0 and left <= Fx.Warn(e) then
				played[e.key] = exp
				Fx.Play(Fx.Get(e, "sExpiring"), "running out: " .. e.label)
			end
		end
	end
end

-- Entering combat: one warning if a "keep up" buff was missing just before. Not if a buff changed
-- since leBoof last could look (in a battleground, say): it can't tell what's missing then.
local function CombatStarted()
	if not state or stale then return end
	local missing, sound = {}, nil
	for _, e in ipairs(ns.Entries()) do
		local mode = ns.Mode(e)
		if (mode == "keep" or mode == "missing") and not state[e.key] then
			local s = Fx.Get(e, "sCombat")
			if s ~= "none" then
				missing[#missing + 1] = e.label
				sound = sound or s
			end
		end
	end
	if #missing > 0 then
		Fx.Play(sound, "entering combat without: " .. table.concat(missing, ", "))
		if ns.db.effects.combatChat then ns.Print("missing: " .. table.concat(missing, ", ")) end
	end
end

-- In combat: "running out" timed from your own casts --------------------------------------------

-- Whether anyone else in the group is of this class (and so could recast a shared buff). A class
-- the game won't tell counts as yes: better silent than wrong.
local function OtherOfClass(class)
	if not IsInGroup() then return false end
	local raid = IsInRaid()
	local count = raid and GetNumGroupMembers() or GetNumSubgroupMembers()
	for i = 1, count do
		local unit = (raid and "raid" or "party") .. i
		local okSelf, isSelf = pcall(UnitIsUnit, unit, "player")
		if not (okSelf and isSelf == true) then
			local ok, _, c = pcall(UnitClass, unit)
			if not ok or Secret(c) or c == class then return true end
		end
	end
	return false
end

-- Whether a cast-timed sound for this buff can be trusted: self-only buffs always; shared buffs
-- (castBy) only when nobody else in the group could have recast them. Buffs you added count as
-- shared with your own class.
function Fx.CastTimingHolds(e)
	local by = e.castBy
	if not by and e.custom then by = select(2, UnitClass("player")) end
	if not by then return true end
	return not OtherOfClass(by)
end

local castTimers = {} -- key -> timer

local function OnCast(spellID)
	if Secret(spellID) then return end
	local e = ns.EntryForSpell(spellID)
	if not e or ns.Mode(e) == "off" or Fx.Get(e, "sExpiring") == "none" then return end
	local duration = Durations()[spellID]
	if not duration then
		for _, id in ipairs(e.idList or {}) do
			duration = duration or Durations()[id]
		end
	end
	if not duration then return end -- not seen out of combat yet
	local warn = Fx.Warn(e)
	if warn <= 0 or warn >= duration then return end
	local ends = GetTime() + duration
	if castTimers[e.key] then castTimers[e.key]:Cancel() end
	castTimers[e.key] = C_Timer.NewTimer(duration - warn, function()
		castTimers[e.key] = nil
		-- While buffs can be read, the buff's real timer does it (CheckExpiring).
		if not ns.AurasHidden() then return end
		-- Someone else in the group may have recast a shared buff since: the timing can't be trusted.
		if not Fx.CastTimingHolds(e) then return end
		castPlayed[e.key] = ends
		Fx.Play(Fx.Get(e, "sExpiring"), "running out: " .. e.label .. " (timed from your cast)")
	end)
end

-- Blizzard's Cooldown Manager ----------------------------------------------------------------

-- Whether the game's Cooldown Manager is available here, and if not, the game's reason.
function Fx.CooldownManager()
	if not (C_CooldownViewer and C_CooldownViewer.IsCooldownViewerAvailable) then
		return false, "This client has no Cooldown Manager."
	end
	local ok, available, reason = pcall(C_CooldownViewer.IsCooldownViewerAvailable)
	if not ok then return false, "The game wouldn't say." end
	return available, reason
end

function Fx.OpenCooldownManager()
	if not C_AddOns.IsAddOnLoaded("Blizzard_CooldownViewer") then
		pcall(C_AddOns.LoadAddOn, "Blizzard_CooldownViewer")
	end
	if CooldownViewerSettings and CooldownViewerSettings.TogglePanel then
		CooldownViewerSettings:TogglePanel()
		return true
	end
	ns.Print("couldn't open the Cooldown Manager's settings. Try /cdm.")
end

-- Events ---------------------------------------------------------------------------------------

local scheduled = false
local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_REGEN_DISABLED")
events:RegisterEvent("WEAPON_ENCHANT_CHANGED")
events:RegisterUnitEvent("UNIT_AURA", "player")
events:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player")
events:SetScript("OnEvent", function(_, event, _, _, spellID)
	if event == "PLAYER_LOGIN" then
		Fx.Update(true)
		C_Timer.NewTicker(1, CheckExpiring)
	elseif event == "PLAYER_REGEN_DISABLED" then
		CombatStarted()
	elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
		OnCast(spellID)
	elseif ns.AurasHidden() then
		stale = true
	elseif not scheduled then
		-- UNIT_AURA, WEAPON_ENCHANT_CHANGED: a moment later, so several changes count as one.
		scheduled = true
		C_Timer.After(0.2, function()
			scheduled = false
			Fx.Update()
		end)
	end
end)
-- What changed while buffs were hidden (a fight, a battleground) isn't announced: start again from
-- what's up now.
ns.OnAurasShown(function() Fx.Update(true) end)
